﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] != null)
        {
            Response.Redirect("~/Login.aspx");
        }
    }
    private Conexion c;

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        c = new Conexion();
    
        
        c.conexion.Open();
        string query = "select count(*) from usuarios where usuario = '" + txtuser.Text + "'and  contraseña = '" + txtpass.Text + "' ";

        SqlCommand cmd = new SqlCommand(query, c.conexion);
        string output = cmd.ExecuteScalar().ToString();

        if (output == "1")
        {
            //creamos la session
            Session["user"] = txtuser.Text;
            Response.Redirect("~/Formulario.aspx");
        }
        else
        {
            Response.Write("Acceso Fallido...");
        }
    }
}