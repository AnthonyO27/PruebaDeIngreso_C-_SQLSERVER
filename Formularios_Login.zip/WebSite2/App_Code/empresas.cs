﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


public class empresas
{
    private int Nit_emp;
    private String rsoc_emp;
    private String dir_emp;
    private String email_emp;
    private int Tel1_emp;
    private String Calt_emp;

    public int Nit_emp1 { get => Nit_emp; set => Nit_emp = value; }
    public string Rsoc_emp { get => rsoc_emp; set => rsoc_emp = value; }
    public string Dir_emp { get => dir_emp; set => dir_emp = value; }
    public string Email_emp { get => email_emp; set => email_emp = value; }
    public int Tel1_emp1 { get => Tel1_emp; set => Tel1_emp = value; }
    public string Calt_emp1 { get => Calt_emp; set => Calt_emp = value; }
}