﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Descripción breve de datos
/// </summary>
public class datos
{
    private Conexion c;
    public datos()
    {
        c = new Conexion();
    }

    //Insertar Representantes_legales

    public void crearRepresentante(Representantes_Legales r)
    {
        String insert = "insert into Representantes_Legales values('" + r.Cc_repleg1 + "','" + r.Nom_repleg + "','" + r.Ape_repleg + "','" + r.Email_repleg + "','" + r.Telefono + "')";
        ejecutar(insert);
    }

    public void crearEmpresa(empresas e)
    {

        String insert = "insert into Empresas values('" + e.Nit_emp1 + "','" + e.Rsoc_emp + "','" + e.Dir_emp + "','" + e.Email_emp + "','" +e.Tel1_emp1 + "','" +e.Calt_emp1 +"')";
        ejecutar(insert);
    }

    public void ejecutar(String sql)
    {
        c.conexion.Open();
        c.sentencia = new SqlCommand(sql, c.conexion);
        c.sentencia.ExecuteNonQuery();
        c.conexion.Close();

    }
}