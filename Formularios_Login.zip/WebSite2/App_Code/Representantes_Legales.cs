﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


public class Representantes_Legales
{
    private  int Cc_repleg;
    private String nom_repleg;
    private String ape_repleg;
    private String email_repleg;
    private int telefono;

    public int Cc_repleg1 { get => Cc_repleg; set => Cc_repleg = value; }
    public string Nom_repleg { get => nom_repleg; set => nom_repleg = value; }
    public string Ape_repleg { get => ape_repleg; set => ape_repleg = value; }
    public string Email_repleg { get => email_repleg; set => email_repleg = value; }
    public int Telefono { get => telefono; set => telefono = value; }
}