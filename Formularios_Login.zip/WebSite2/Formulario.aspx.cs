﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Default2 : System.Web.UI.Page
{
    private datos d;
    private Conexion c;
    DataSet daDepartamentos;
    protected void Page_Load(object sender, EventArgs e)
    {


        if (Session["user"] != null)
        {
            txtusu.Text = "Bienvenido " + Session["user"].ToString();
            d = new datos();
            c = new Conexion();
            if (!IsPostBack)
            {
                cargarDepartamentos();
            }


        }
        else
        {
            Response.Redirect("~/Login.aspx");
        }
    }

    protected void btnsalir_Click(object sender, EventArgs e)
    {
        Session.Remove("user");
        Response.Redirect("~/Login.aspx");
    }



    protected void btAgregarRL_Click(object sender, EventArgs e)
    {
        Representantes_Legales rp = new Representantes_Legales();
        if (Page.IsValid)
        {
            rp.Cc_repleg1 = int.Parse(txtCedulaR.Text);
            rp.Nom_repleg = txtnombre.Text;
            rp.Ape_repleg = txtApellido.Text;
            rp.Email_repleg = txtEmail.Text;
            rp.Telefono = int.Parse(txtTelefono.Text);

            d.crearRepresentante(rp);
            
        }
        else
        {
            Response.Write("Por favor llene todos los campos");
        }


    }
    public void cargarDepartamentos()
    {
        c.conexion.Open();
        SqlCommand com = new SqlCommand("SELECT  id_dep,nombre FROM Departamentos", c.conexion);
        SqlDataReader dr = com.ExecuteReader();
        lbDepartamentos.DataSource = dr;
        lbDepartamentos.Items.Clear();
        
        lbDepartamentos.DataTextField = "nombre";
        lbDepartamentos.DataValueField = "id_dep";
        lbDepartamentos.DataBind();
        lbDepartamentos.Items.Insert(0, new ListItem("[Seleccionar Departamento]", "0"));
        c.conexion.Close();



    }


    public void cargarM()
    {
        c.conexion.Open();
        SqlCommand cmd = new SqlCommand("SELECT  * FROM municipio where departamento_iddepartamento=@id_dep", c.conexion);
        cmd.Parameters.AddWithValue("@id_dep", lbDepartamentos.SelectedValue);
        SqlDataAdapter adacterDep = new SqlDataAdapter(cmd);

        daDepartamentos = new DataSet();

        adacterDep.Fill(daDepartamentos, "municipio");

        lbCiudades.DataSource = daDepartamentos.Tables["municipio"].DefaultView;
        lbCiudades.Items.Clear();
        
        lbCiudades.DataTextField = "nombreMunicipio";
        lbCiudades.DataValueField = "idmunicipio";
        lbCiudades.DataBind();
        lbCiudades.Items.Insert(0, new ListItem("[Seleccionar Municipio]", "0"));

        c.conexion.Close();
    }
    protected void lbDepartamentos_SelectedIndexChanged(object sender, EventArgs e)
    {
        cargarM();
    }

    protected void btnAggEmp_Click(object sender, EventArgs e)
    {
        empresas emp = new empresas();
        if (Page.IsValid)
        {
            emp.Nit_emp1 = int.Parse(txtnit.Text);
            emp.Rsoc_emp= txtRazonSocial.Text;
            emp.Dir_emp = txtdireccion.Text;
            emp.Email_emp = txtemailEC.Text;
            emp.Tel1_emp1 = int.Parse(txttelefonoEC.Text);
            emp.Calt_emp1 = txtContal.Text;
            d.crearEmpresa(emp);

        }
        else
        {
            Response.Write("Por favor llene todos los campos");
        }
    }
}



